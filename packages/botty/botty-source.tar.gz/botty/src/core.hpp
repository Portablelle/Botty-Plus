#pragma once
#include "json.hpp"
#include <filesystem>
#include <functional>
#include <string>
#include <vector>
namespace botty {
namespace fs = std::filesystem;
using json = nlohmann::json;
struct Paths {
  fs::path root, complete, extracted, jobs, library;
  explicit Paths(fs::path data = "/data/botty", fs::path games = "/data/homebrew")
    : root(std::move(data)), complete(root/"downloads/complete"), extracted(root/"extracted"), jobs(root/"jobs"), library(std::move(games)) {}
};
inline std::string asciiLower(std::string text){for(char& c:text)if(c>='A'&&c<='Z')c=char(c+32);return text;}
int makeDirectoryRelative(int,const char*,unsigned);
int openFileRelative(int,const char*,int,unsigned=0);
std::string readText(const fs::path&, size_t limit = 1024*1024);
void writeJson(const fs::path&, const json&);
fs::path safeRelative(const std::string&);
fs::path containedExisting(const fs::path& root, const fs::path& path);
uint64_t freeBytes(const fs::path&);
using DeleteProgress = std::function<void(uint64_t,uint64_t,const std::string&)>;
// Exact torrent members only; never recurse into a download or library folder.
void downloadedFiles(const fs::path& root, const std::vector<fs::path>& files, bool remove, const DeleteProgress& progress = {});
std::string randomId();
json classify(const fs::path& extracted);
json movePrepared(const Paths&, json job, const Paths* destination = nullptr, const std::function<void()>& check = {});
void prepareLibraryPermissions(const fs::path&);
void deleteGameDirectory(const fs::path& root,const fs::path& name, const DeleteProgress& progress = {});
void deleteLibraryGame(const Paths&, const json& job, const DeleteProgress& progress = {});
struct Progress { std::string phase, file; uint64_t bytes = 0, total = 0; };
using Reporter = std::function<void(const Progress&)>;
// Progress callbacks are serialized; cancellation may be queried concurrently.
void extractRar(const fs::path& archive, const fs::path& destination, Reporter report, const std::string& password = "", std::function<bool()> cancelled = {}, unsigned workers = 0, bool resume = false);
}
