# Botty+ native application — 01.007.000

Botty+ is a C++20 native PS5 title with a 1920×1080 software renderer, bundled
Manrope font and DualSense navigation. Its title ID is `PPSA99071`. It connects to
Botty API v1 on loopback port 8088; download and extraction work runs in separate
services. The native title does not register another web shortcut.

For hosting and first installation, use the [root README](../../README.md) and
[deployment guide](../../deployment/README.md). Select **LAUNCH** on the PS5 portal,
then open **Botty+** after discovery. The installer updates recognized older Botty versions with the app closed, after
verifying staging and retaining a private rollback copy. It refuses unrelated
titles and downgrades. A journal recovers interrupted swaps. See the deployment
guide for recovery and manual rollback.

## Screens and controls

L1/R1 switches **Discover → Activity → Library → System**. D-pad/stick moves the
focus, shown as a white ring. Cross selects and Circle goes back; Circle on a
tab never opens a quit dialog: **Close Botty+** lives in System. Safe actions
(pause, resume, verify) run immediately. Every destructive action keeps a
separate confirmation, shown inline with Cancel focused.

- **Discover:** the focused game leads a cover shelf with its art, size,
  seeders and grabs. Triangle cycles Newest / Most seeded / Most grabbed; R3
  refreshes saved results when they are labeled. Cross opens the **Get game**
  sheet and Options (Compare sources) opens it on the source row. Square opens
  the PS5 keyboard to **search all trackers**; results replace the shelf, Square
  edits the query and Circle returns to the shelf. Recognized owned or
  downloaded titles are hidden; artwork may remain unavailable for some titles.
- **Get game sheet:** one sheet for Discover, search results and magnet links,
  with source, install-on disk and after-download rows. Up/down moves between
  rows and the **Get game** button, which is focused first; left/right changes
  the focused row. The best-seeded source, the last disk and the last mode
  (Full auto or Download only) are preselected for the session. Cross starts the
  download; a short toast confirms it without another screen.
- **Activity:** downloads, extractions, moves, compression and deletion in one
  list, with a Download → Extract → Library pipeline on the focused row. Rows are
  grouped running, needs you, waiting and done; left/right filters them. Rows
  from different sources are never merged by name. Cross opens details with
  action buttons and files; Options opens **Quick actions**; Square adds a
  magnet link; Triangle refreshes.
- **Extract sheet:** the first archive set is picked automatically when there
  is only one; left/right chooses another. The optional password is entered with
  the PS5 keyboard only when needed (Square), Triangle reveals it, and the
  destination row defaults to the download's disk. Original archives are kept.
- **Library:** a seven-column cover grid; left/right moves one card, up/down
  one row and Triangle filters All / PS5 SSD / External / Compressed. Cross
  opens details and Options opens Quick actions (compress, move, delete). This
  screen does not launch games.
- **System:** web address, username and password for LAN access, installation
  updates, **Reconnect to the service** and **Close Botty+**. When an update is
  available, **Update and close** shows its versions and asks once more, with
  Cancel focused, before queueing it.

Success toasts disappear after four seconds and never block input. Failures and
uncertain results stay on screen until Circle dismisses them; that press does
nothing else. Searches and Explore refreshes report only failures.

Text entry opens the PS5 system keyboard for searches, magnet links and
optional archive passwords. Passwords use the system's masked, no-learning mode.
Cancelling the system dialog keeps the entry screen without sending a request;
Cross reopens it, Square selects the in-app keyboard for longer links, and
Circle cancels (a password edit returns to the Extract sheet unchanged).

The system dialog accepts up to 2,048 UTF-16 code units; Botty also enforces its
byte limits (200 for searches, 1,024 for passwords and 16,384 for magnets) without
silently truncating input. Entries exceeding the byte limit reopen with their
edits intact so they can be shortened; confirmation during an in-flight request
is retained until that request finishes. IME startup gets
a bounded ten-second window before falling back. Magnet input reaching the
system's 2,048-unit cap goes to the in-app editor for explicit review, since
IME may have trimmed a paste. It is not automatically accepted. If the system dialog is unavailable or cannot handle
an existing long input, the QWERTY in-app keyboard remains available with a number
row, uppercase and symbols via L1/R1. Square erases, Triangle reveals/hides a
password, and Options accepts a hexadecimal Unicode code point. Characters
outside the font atlas are sent as UTF-8 but displayed as `?`. Empty archive
passwords can be submitted. Native keyboard acceptance must be tested on PS5;
host tests simulate its ABI and lifecycle.

One action request can be in flight at a time. A lost response is reported as
uncertain and is not automatically repeated. Network work is bounded and runs
outside the render loop. Input-release guards prevent one button press from both
opening and confirming a dialog. Missing service capabilities disable related
actions instead of pretending they succeeded.

## Installation updates

Starting with Botty+ 1.6.0, the header and footer share one public version.
`release.json` generates the compiled identities, PS5 `contentVersion` and
build asset through `python3 tools/release_version.py`. System shows
technical component versions. See [versioning](../../docs/VERSIONING.md).

Installation updates require native 1.4.2 or later, manager 1.5.4, worker revision 1.3.1
and rTorrent botty5 or later. Use Portal+ once to install this initial stack in
a deliberately restarted idle console session. Legacy workers and engines do
not expose enough running-process identity for unattended retirement; the updater
refuses to guess or stop them. Older services show a Portal notice instead of
claiming that the entire installation is current.

The header reports installation currency across the app, manager, worker and
engine. The button checks the verified packages on this repository's `main`,
including the native manifest's minimum service versions and API contract. It
also offers service-only updates when the native app is already current.
After a durably acknowledged request, the app exits normally. Compression,
activation, verification and other file operations finish before the independent
updater takes over. Downloads continue unless the engine must restart; only
updater-paused downloads are resumed. Close other native apps too, and reopen
Botty+ after the completion notification. Lost or invalid confirmations do not
invoke normal app exit or automatically replay the request.

Replacement files are hash-verified. The previous native title is backed up
before publication; registered metadata is refreshed with retained backups
after publication. Services use separate immutable version directories. The
updater confirms running identities and orderly exits before starting replacements,
then confirms the replacements before reporting success. Ambiguous retirement or
startup is not repeated automatically and requires recovery with retained files.
Do not run a Portal installer concurrently. Keep the journals and backups until
the updated installation is accepted. Host tests and previews are not PS5 acceptance.

## Build and validation

From this directory:

```sh
make test
make preview       # macOS only: uses sips to produce build/preview.png
make integration   # first build the service in ../botty
```

Preview uses the actual renderer with simulated network/controller APIs. It is
not a console screenshot. To select another state:

```sh
BOTTY_PREVIEW_MODE=system ./build/preview
```

Each redesigned screen has a scenario: `discover`, `get-game`, `compare`,
`search-typing`, `search`, `keyboard` (in-app magnet editor), `activity`
(default), `details`, `extract`, `password`, `library`, `library-details`,
`quick-actions`, `delete-game`, `system`, `update-confirm`, `result` (success
toast) and `error-toast`. Others include `offline`, `reconnecting`, `quit`,
`exit`, `deleting` and `checking-deletion`. `BOTTY_PREVIEW_STATE_FILE` can
provide synthetic state for long-name and full-list layout checks, and
`BOTTY_PREVIEW_COVERS` can name a directory of 160×240 RGB covers matched by
title (`Astro Bot` loads `astro-bot.rgb`); titles without a file keep the
generated fallback. Font and illustration tools use Pillow; the recorded asset-generation
version is 12.0.0. Assets are already bundled. The font atlas holds Manrope at
600 (text) and 800 (titles) for sizes 20–76, plus the separators and arrows the
interface uses.

Cross-build the native title with its own pinned runtime:

```sh
docker build --platform linux/amd64 -t botty-native-build .
docker run --rm --platform linux/amd64 -v "$PWD:/work" botty-native-build
python3 tools/verify_package.py
```

The output includes `dist/PPSA99071/`, `PPSA99071.zip`, `manifest.json`,
`SHA256SUMS`, source archive and resolved tool versions. Python 3.12+ is used by
the PS5 builder's safe tar extraction; the Docker image supplies it.
`BUILD-ENVIRONMENT.json` and `vendor/NOTICE.md` record pinned dependencies.
The native runtime uses SDK v0.42 and is independent of the service's v0.43
runtime. Resolved apt package versions can change between image builds.

From the repository root, publish that verified build and check the Botty+
delivery contract:

```sh
python3 scripts/package-native.py
python3 scripts/botty-packages.py --check
```

For documentation-only changes, `package-native.py --source-only` updates the
source archive and license notices without changing the native executable.
The title manifest deliberately retains `hardwareValidated: false` and
`registrationVerified: false`; see [the validation record](VALIDATION.md).

## Runtime and installation constraints

The title is installed as a complete directory at `/data/homebrew/PPSA99071`, not
as a ZIP or ELF payload. Keep `downloadDataSize` at **256**: firmware 13.00 rejected
the earlier value 16 before entering `main`. Inventory the target title ID before
publication; this is a provisional homebrew identity, not a globally reserved ID.

The thirteen runtime files, native FSELF signatures, metadata, hashes and matching
ZIP are validated by `tools/verify_package.py`. Transfer through a staging path
outside `/data/homebrew`, read back and hash every file, then publish atomically
with the app closed. Preserve the full previous title for rollback.

Diagnostics begin at `main` in `/download0/botty-native-network.log`, with at most
256 fixed messages per launch. They exclude tokens, passwords and raw responses.
Loader failures before `main` require system logs. Quit frees rendering resources,
joins the network thread and requests system exit; suspension, quitting and
service survival still require the remaining hardware acceptance checks.

Closing the UI is intended to leave Transmission and extraction running. Do not
remove `/data/botty` to uninstall the native title. Keep the console awake during
work; rest-mode support is not established.

During a slow local refresh, the app keeps its last catalog with a Reconnecting indicator and disables mutations until a fresh response arrives. Transmission RPC failures preserve the previous downloads while extraction jobs continue updating. Transient failures retry automatically after one second; the receive timeout allows five seconds under disk load.

### Library deletion

For a moved game folder, Library → Options offers **Delete game**, with Cancel selected by default. This deletes the installed game files while keeping the torrent and original archives. Close the game and remove its home-screen entry first; mounted games are refused. The action requires a service advertising `libraryDeletionSupported`. Image-based games require manual unmounting/removal. **Remove from Activity** only hides an extraction row and is no longer offered in Library.

## Home-screen music

`sce_sys/snd0.at9` contains the user-provided music excerpt from 01:19 to
02:19, normalized toward -28 LUFS with short fades and an embedded whole-file
loop. It is stereo ATRAC9 at 48 kHz / 192 kbit/s. The installer preserves its
metadata backup indices and appends the sound to registered metadata updates.
This asset-only update keeps the native executable version unchanged. The
console Home Screen Music option must be enabled for playback.

## Earlier screen names

The release notes below keep the names used when each feature shipped. Explore
and Search are now **Discover**, Downloads and Processing are **Activity**, and
Connections is **System**. Storage, download-mode and confirmation steps are now
rows of one sheet; per-item actions are **Quick actions**.

## Library compression (1.2)

Library → Options → **Compress game** creates a separate compressed PS5 folder
game. Close Botty+ when prompted so ShadowMount can mount and verify every file.
Test the game before selecting **Delete uncompressed copy**. That action verifies
the image again and retains saves, compressed content and download archives.
**Restore uncompressed game** can return to a retained original. Existing images
and APR games without an existing index are not supported by this workflow. See the game-compressor component
for build instructions, dependency notices and validation limits.

In 1.2.1, compressed games show **Delete game** even when the original and
torrent archives are absent. After confirmation, close Botty+ and games so the
service can unmount and delete the image, verification sidecar and any retained
original. Saves and downloaded archives are preserved. Already-compressed games
do not offer **Compress game**. A service capability flag prevents newer clients
from offering deletion against an older service. Interrupted deletion stays locked
for inspection rather than repeating automatically.


## Storage selection (1.3)

Native 01.003.002 reads the service's storage catalog and free capacity. Adding
a game opens storage selection, Full auto / Download only, then confirmation.
Extraction, publication and compression default to the current disk and let the
user choose another one. Options exposes Transfer to another disk for torrent
data, ready extractions and Library content. Transfer progress and recovery
errors remain visible; closing the app leaves the background operation running.
These features require service 1.3.0 and its library-1.3 compression worker for
external compression. Host previews are not PS5 acceptance.

## Processing (01.003.002 / service 1.3.1)

Processing replaces Extracted and combines active extractions, compression and
deletion with extraction results. Active tasks come first. A separate authenticated
`/api/processing` connection polls every second while long deletion requests run.
The current phase, counters, rate, elapsed time and phase ETA are shown. Deletion
counts checked file/directory removals; compression and verification count bytes.
ETA resets between phases and is unavailable while waiting, reconnecting or before
a useful rate sample. Original archives and saves keep their existing protections.
The panel retains the latest deletion/compression result in this service session;
it is not a durable history of every past operation.

Validated with host tests and the native renderer preview. After the 01.003.001
stack overflow was corrected in 01.003.002, the user confirmed that Botty+ opens
and Processing works on PS5.

When external storage is connected, its name and free space appear below the
PS5 free-space card in Downloads and Processing. Disconnected disks are hidden.

## Library copy labels (1.3.2 / native 01.003.003)

Library covers show Compressed, Uncompressed or Both formats. Each copy has its
own storage label: PS5 SSD, named external SSD, or Offline. Verified compressed
copies and retained originals use their separate target/source storage IDs.
Restored originals retain a second compressed-copy label; pending
compression does not claim a completed compressed copy. Service remains 1.3.1.

Host model/parser regressions cover split storage, removed originals, pending
compression, restoration and missing disks. The actual renderer preview covers
six representative cards; native integration and package checks pass. On firmware
13.00 the user reported successful LAUNCH, and console reads confirmed native
01.003.003 with service 1.3.1 active. Visual acceptance of all copy/storage
combinations on console remains separate from the host previews.

The portal accepts the two historical completed manual-update journals and
bounds native file reads at 32 MiB, allowing the current executable above 16 MiB.
Installer tests enforce actual read limits and cover larger previous executables.

## Delete uncompressed copy (01.003.006 / service 1.3.5)

Original deletion does not perform another full comparison or require a successful
compression verification flag. The confirmation explains this explicitly. The
service still checks the retained backup, compressed image path and closed-game
state before deleting only the original. Active file operations remain protected.

## Prowlarr source chooser (01.003.006)

Explore combines the configured torrent indexers. Select a game to compare tracker, release name, size, seeders, leechers, grabs and date before choosing storage, download mode and confirming. Circle cancels without adding a torrent. The source list is captured when opened so background polling cannot change the selected tracker.
