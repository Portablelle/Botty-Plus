Complete corresponding sources are stored losslessly in the hashed parts listed in manifest.json.
From a complete repository checkout, run:
  python3 restore.py /path/to/packages/botty-native complete-source.tar.gz
For Portal, use /path/to/apps/botty-native instead. Extract complete-source.tar.gz to build.
The entry archive is not the complete source tree on its own.
